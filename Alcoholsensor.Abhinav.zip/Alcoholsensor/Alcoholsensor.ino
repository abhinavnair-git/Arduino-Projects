#include<MQ135.h>
#define pin A2

int x;
int buzzer=7;
const int switchPin = 2; 
MQ135 mq135_sensor(pin);


void setup() {
Serial.begin(9600);
  pinMode(switchPin, INPUT_PULLUP); 
pinMode(buzzer,OUTPUT);


}

void loop() {
   int switchState = digitalRead(switchPin);
   Serial.print("\t Switch State: ");
  Serial.println(switchState);
  if(switchState==0)
  {
  x=analogRead(pin);
    Serial.println(x);
    if(x>=200)
    {
      digitalWrite(buzzer,HIGH);
      delay(1000);
      digitalWrite(buzzer,LOW);
    }}
  digitalWrite(buzzer,LOW);

}
