#define SENSOR_PIN 2 
#include<Servo.h>
static int servo=3;
Servo Motor;

void setup() {
  Serial.begin(115200);
  pinMode(SENSOR_PIN, INPUT);
  Motor.attach(servo);
}

void loop() {
  int state = digitalRead(SENSOR_PIN);

  if (state == LOW)
   { Serial.println("The obstacle is present");
  Motor.write(90);
  }
else{
    Serial.println("The obstacle is NOT present");
    Motor.write(0);
  }
  delay(1000);
}