const int ldrPin = 4;     
const int switchPin = 2;  
int led=7;  
void setup() {
  Serial.begin(9600);       
  pinMode(switchPin, INPUT_PULLUP); 
  pinMode(led,OUTPUT);
}

void loop() {
  int switchState = digitalRead(switchPin);
Serial.print("\t Switch State: ");
  Serial.println(switchState);
  if(switchState==1)
  {
    int ldrValue = digitalRead(ldrPin);
    Serial.print("LDR Value: ");
  Serial.print(ldrValue);
   if(ldrValue==1)
  {
    digitalWrite(led,HIGH);
  }
  else
  {
    digitalWrite(ldrPin,LOW);
  
  if(ldrValue==1)
  {
    digitalWrite(led,HIGH);
  }
else
  {
    digitalWrite(led,LOW);
  }}

  
  }}